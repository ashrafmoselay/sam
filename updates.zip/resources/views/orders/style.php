<style type="text/css">
	.qtystyle{
	    position: absolute;
	    font-size: 12px;
	    display: none;
	    min-width: 24px;
	    z-index: 10;
	}
	span.afqty {
	    margin-top: -70px;
	    margin-right: 50px;
	    padding: 4px;
	}
	span.tqty {
	    margin-right: -80px;
	    padding: 4px;
	}
	input.qty,input.total{
		text-align: center;
	}
</style> 