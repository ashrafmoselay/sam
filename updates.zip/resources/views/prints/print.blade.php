<style type="text/css">
	table {
    	border-collapse: collapse;
	}
	table tr, th, td {
		position: relative;
		font-size: 12px;
	    border: 1px solid black;
	    text-align: center;
	    height: 28px;
	}
	td{
	    vertical-align: middle;
	}
</style>